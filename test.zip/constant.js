export const ACCESS_TOKEN = "access"
export const STORAGE_TYPE = "storage_type"
export const USER_DATA = "user_data"
